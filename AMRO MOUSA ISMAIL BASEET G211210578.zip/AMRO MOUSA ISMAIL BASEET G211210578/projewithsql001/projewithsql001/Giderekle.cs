﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2021-2022 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:(3)PROJE
**				ÖĞRENCİ ADI............:AMRO MOUSA ISMAIL BASEET
**				ÖĞRENCİ NUMARASI.......:G211210578
**                         DERSİN ALINDIĞI GRUP...:2. Öğretim A grubu
****************************************************************************/

using System;
using System.Windows.Forms;
using System.Drawing;

namespace projewithsql001
{
    public partial class Giderekle : Form
    {
        //çok kontrol edilecek için hepsıne statiğe yaptım
        public static float Borc;
        public static string Adi;

        public Giderekle()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterParent;//bir önceki sayfanının ortasında açılacak
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önlers
            this.MaximizeBox = false;//form buytme engellir
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum


            //PLACEHOLDER tanitiyorum

            //adisoyadi alan icin PLACE HOLDER TANITIYORUM

            txt_adi.Text = "HARF GİRİN";
            txt_adi.GotFocus += Txt_adi_GotFocus;//txt_adi aktiv oldugu zamn texti siliyor 
            txt_adi.Click += Txt_adi_Click;
            txt_adi.LostFocus += Txt_adi_LostFocus;

            //borcu alan icin PLACE HOLDER TANITIYORUM

            txt_borcu.Text = "SAYI GİRİN";
            txt_borcu.GotFocus += Txt_borcu_GotFocus;
            txt_borcu.LostFocus += Txt_borcu_LostFocus;
            txt_borcu.Click += Txt_borcu_Click;

        }

        //borcu alan icin PLACE HOLDER TANITIYORUM

        private void Txt_borcu_LostFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (string.IsNullOrWhiteSpace(txt_borcu.Text))
            {
                txt_borcu.Text = "SAYI GİRİN";
            }
        }

        private void Txt_borcu_Click(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_borcu.Text == "SAYI GİRİN")
            {
                txt_borcu.Text = "";
            }
        }

        private void Txt_borcu_GotFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_borcu.Text == "SAYI GİRİN")
            {
                txt_borcu.Text = "";
            }
        }

        //adisoyadi alan icin PLACE HOLDER TANITIYORUM

        private void Txt_adi_Click(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_adi.Text == "HARF GİRİN")
            {
                txt_adi.Text = "";
            }
        }


        private void Txt_adi_LostFocus(object sender, EventArgs e)
        {

            //placeholder tanitiyorum
            if (string.IsNullOrWhiteSpace(txt_adi.Text))
            {
                txt_adi.Text = "HARF GİRİN";
            }
        }

        private void Txt_adi_GotFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_adi.Text == "HARF GİRİN")
            {
                txt_adi.Text = "";
            }
        }
        // dışardan tum alınacak bilgileri bosluklar silecegimki hata azalatmasi icin 

        void Gdrekle() { //fonksiyon tanitim
          
            Giderler  Gider =new Giderler();//giderler sınıfından bir nesne uretim ve onun özeliklerine bilgileri attım
            Gider.Adi = Adi;
            Gider.Tur = "GIDER";
            Gider.Borc = Borc;
            Magaza.Giderekle(Gider);
            MessageBox.Show(Adi + " gideri veri tabana Başarıyla eklenmiştir", "Ekleme Yapıldı ", MessageBoxButtons.OK, MessageBoxIcon.Information);


        }
        // dışardan tum köntrol edilecek bilgileri bosluklar silecegimki hata azalatmasi icin 

        private void button1_Click(object sender, EventArgs e)
        {
            bool fiatdegilise;
            bool harfdegilise;
            fiatdegilise = Magaza.Fiat(txt_borcu.Text);
            harfdegilise = Magaza.Harf(txt_adi.Text);
            //BURDA HARF ALANLARI KÖNTRUL EDİYORUM EĞER KULLANCI ONDAN BİRİ DOLDURUMAYI UNUTTUR ISE HATA VERECEK
            if (!(txt_adi.Text.Contains("HARF GİRİN")))
            {
                if (fiatdegilise == false|| harfdegilise==false)//Bilirtildiği gibi girin sayı ise sayı ve Harf ise harf
                {
                    MessageBox.Show("Bilirtildiği gibi girin sayı ise sayı ve Harf ise harf ", "ekleme Yapamazsın  ", MessageBoxButtons.OK, MessageBoxIcon.Error);


                }
                else
                {
                    //girilenleri kontrol ediyorum sayidan farkli ya da harftan farkli bir sey giririse
                    Adi = txt_adi.Text.Replace(" ", string.Empty);
                    Borc = Convert.ToSingle(txt_borcu.Text.Replace(" ", string.Empty));

                    Gdrekle();//ekle fonk çağırdım
                    this.Close();
                }


            }
            else
            {
                MessageBox.Show("HARF ALANI DOĞURU DOLDURUN", "ekleme yapamazsın  ", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
    }
}
