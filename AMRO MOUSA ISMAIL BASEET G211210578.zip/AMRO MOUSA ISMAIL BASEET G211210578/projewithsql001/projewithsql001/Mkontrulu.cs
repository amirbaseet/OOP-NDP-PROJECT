﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2021-2022 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:(3)PROJE
**				ÖĞRENCİ ADI............:AMRO MOUSA ISMAIL BASEET
**				ÖĞRENCİ NUMARASI.......:G211210578
**                         DERSİN ALINDIĞI GRUP...:2. Öğretim A grubu
****************************************************************************/

using System;
using System.Data;
using System.Windows.Forms;
using System.Drawing;
using System.Data.SQLite;


namespace projewithsql001
{
    public partial class Mkontrulu : Form
    {

        public Mkontrulu()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterParent;//bir önceki sayfanının ortasında açılacak
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önler
            this.MaximizeBox = false;//form buytme engellir
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum
            
            dataGridView1.AutoResizeRows();//sütuna sığdırmak için
            dataGridView1.AutoResizeColumns();
            this.dataGridView1.AutoSize = true;


        }
        void Listeleme() {

            using (var Connection = new SQLiteConnection(Magaza.project))//verı tabanı ile bağlantı kurmak
            {
                //bağlanacak veri tabanı adressi kompaylara vermek

                Connection.Open();//veri tabanımı açtım

                SQLiteDataAdapter adapter= new SQLiteDataAdapter("SELECT * FROM musteri WHERE tc IS NOT NULL", Connection);//veri tabandaki tüm verileri getirdim 

                DataTable table = new DataTable();//bir tablo oluşturdum

                adapter.Fill(table);//oluşturduğum tablete veri tabandaki getirdiğim belgileri doldurdum
                dataGridView1.DataSource = table;//bu tablo datagridview e gönderdim
                dataGridView1.AutoResizeRows();//sütuna sığdırmak için
                dataGridView1.AutoResizeColumns();


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MUSTERIEKLE mUSTERIEKLE = new MUSTERIEKLE();
            mUSTERIEKLE.ShowDialog();

        }

        private void Mkontrulu_Activated(object sender, EventArgs e)
        {
            Listeleme();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Musterisilme musterisilme = new Musterisilme();
            musterisilme.ShowDialog();
        }
    }
}
