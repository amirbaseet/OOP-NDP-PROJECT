﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2021-2022 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:(3)PROJE
**				ÖĞRENCİ ADI............:AMRO MOUSA ISMAIL BASEET
**				ÖĞRENCİ NUMARASI.......:G211210578
**                         DERSİN ALINDIĞI GRUP...:2. Öğretim A grubu
****************************************************************************/

using System;
using System.Data;
using System.Windows.Forms;
using System.Drawing;
using System.Data.SQLite;


namespace projewithsql001
{
    public partial class sipariset : Form
    {
        SQLiteDataAdapter adapter;
        void tedarikcilisteleme()
        {

            using (var connection = new SQLiteConnection(Magaza.project))//verı tabanı ile bağlantı kurmak
            {
                //bağlanacak veri tabanı adressi kompaylara vermek

                connection.Open();//veri tabanımı açtım

                adapter = new SQLiteDataAdapter("SELECT * FROM tdrkci WHERE  tedarikcitc IS NOT NULL", connection);//veri tabandaki tüm verileri getirdim 

                DataTable table = new DataTable();//bir tablo oluşturdum

                adapter.Fill(table);//oluşturduğum tablete veri tabandaki getirdiğim belgileri doldurdum
                dataGridView1.DataSource = table;//bu tablo datagridview e gönderdim

            }
        }
        void Urun_listeleme()
        {

            using (var connection = new SQLiteConnection(Magaza.project))//verı tabanı ile bağlantı kurmak
            {
                //bağlanacak veri tabanı adressi kompaylara vermek

                connection.Open();//veri tabanımı açtım

                adapter = new SQLiteDataAdapter("SELECT * FROM Stock WHERE kode  IS NOT NULL", connection);//veri tabandaki tüm verileri getirdim 

                DataTable table = new DataTable();//bir tablo oluşturdum

                adapter.Fill(table);//oluşturduğum tablete veri tabandaki getirdiğim belgileri doldurdum
                dataGridView2.DataSource = table;//bu tablo datagridview e gönderdim

            }
        }
        public sipariset()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterParent;//bir önceki sayfanının ortasında açılacak
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önler
            this.MaximizeBox = false;//form buytme engellir
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum
            dataGridView2.AutoResizeColumns();
            dataGridView1.AutoResizeColumns();
            dataGridView1.AutoResizeRows();//sütuna sığdırmak için
            dataGridView2.AutoResizeRows();//sütuna sığdırmak için
            this.dataGridView1.AutoSize = true;

        }

        private void sipariset_Load(object sender, EventArgs e)
        {
            tedarikcilisteleme();
            Urun_listeleme();
        }

        private void sipariset_Activated(object sender, EventArgs e)
        {
             tedarikcilisteleme();
            Urun_listeleme();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Urunsipariset urunsipariset = new Urunsipariset();
            urunsipariset.ShowDialog();
        }
    }
}
