﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2021-2022 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:(3)PROJE
**				ÖĞRENCİ ADI............:AMRO MOUSA ISMAIL BASEET
**				ÖĞRENCİ NUMARASI.......:G211210578
**                         DERSİN ALINDIĞI GRUP...:2. Öğretim A
****************************************************************************/

using System;
using System.Windows.Forms;
using System.Drawing;
using System.Data.SQLite;

namespace projewithsql001
{

    public partial class MUSTERIEKLE : Form
    {
        //çok kontrol edilecek için hepsıne statiğe yaptım
        public static int Tc;
        public static int Telefonno;
        public static int Yas;
        public static string Adisoyadi;
        //bunlari kullanarak girilenende istenenden farkli ise bilirtmek
        bool sayidegilise;
        bool harfdegilise;
        //tum sayi alanlari burda olsun
        string Sayi;
        public MUSTERIEKLE()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterParent;//bir önceki sayfanının ortasında açılacak
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önler
            this.MaximizeBox = false;//form buytme engellir
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum
            
            cmb_cinsiyet.SelectedIndex = 0;
            //tc alan icin PLACE HOLDER TANITIYORUM
            txt_Mtc.Text = "SAYI GİRİN";
            txt_Mtc.GotFocus += Txt_Mtc_GotFocus;
            txt_Mtc.LostFocus += Txt_Mtc_LostFocus;
            txt_Mtc.Click += Txt_Mtc_Click;

            //telefon no alan icin PLACE HOLDER TANITIYORUM
            txt_Mtelno.Text = "SAYI GİRİN";
            txt_Mtelno.GotFocus += Txt_Mtelno_GotFocus;
            txt_Mtelno.LostFocus += Txt_Mtelno_LostFocus;
            txt_Mtelno.Click += Txt_Mtelno_Click;

            //yas alan icin PLACE HOLDER TANITIYORUM
            txt_Myas.Text = "SAYI GİRİN";
            txt_Myas.LostFocus += Txt_Myas_LostFocus;
            txt_Myas.Click += Txt_Myas_Click;
            txt_Myas.GotFocus += Txt_Myas_GotFocus;

            //adisoyadi alan icin PLACE HOLDER TANITIYORUM
            txt_Madisoyadi.Text = "HARF GİRİN";
            txt_Madisoyadi.LostFocus += Txt_Madisoyadi_LostFocus;
            txt_Madisoyadi.GotFocus += Txt_Madisoyadi_GotFocus;
            txt_Madisoyadi.Click += Txt_Madisoyadi_Click;
        }


        //tc alan icin PLACE HOLDER TANITIYORUM

        private void Txt_Mtc_Click(object sender, EventArgs e)
        {

            //placeholder tanitiyorum
            if (txt_Mtc.Text == "SAYI GİRİN")
            {
                txt_Mtc.Text = "";
            }
        }
        private void Txt_Mtc_LostFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (string.IsNullOrWhiteSpace(txt_Mtc.Text))
            {
                txt_Mtc.Text = "SAYI GİRİN";
            }
        }

        private void Txt_Mtc_GotFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_Mtc.Text == "SAYI GİRİN")
            {
                txt_Mtc.Text = "";
            }
        }

        //telefon no alan icin PLACE HOLDER TANITIYORUM

        private void Txt_Mtelno_Click(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_Mtelno.Text == "SAYI GİRİN")
            {
                txt_Mtelno.Text = "";
            }
        }
        private void Txt_Mtelno_LostFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (string.IsNullOrWhiteSpace(txt_Mtelno.Text))
            {
                txt_Mtelno.Text = "SAYI GİRİN";
            }
        }
        private void Txt_Mtelno_GotFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_Mtelno.Text == "SAYI GİRİN")
            {
                txt_Mtelno.Text = "";
            }
        }


        //adisoyadi alan icin PLACE HOLDER TANITIYORUM

        private void Txt_Madisoyadi_LostFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (string.IsNullOrWhiteSpace(txt_Madisoyadi.Text))
            {
                txt_Madisoyadi.Text = "HARF GİRİN";
            }

        }
        private void Txt_Madisoyadi_Click(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_Madisoyadi.Text == "HARF GİRİN")
            {
                txt_Madisoyadi.Text = "";
            }
        }
        private void Txt_Madisoyadi_GotFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_Madisoyadi.Text == "HARF GİRİN")
            {
                txt_Madisoyadi.Text = "";
            }
        }



        //yas alan icin PLACE HOLDER TANITIYORUM

        private void Txt_Myas_LostFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (string.IsNullOrWhiteSpace(txt_Myas.Text))
            {
                txt_Myas.Text = "SAYI GİRİN";
            }

        }
        private void Txt_Myas_Click(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_Myas.Text == "SAYI GİRİN")
            {
                txt_Myas.Text = "";
            }
        }
        private void Txt_Myas_GotFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_Myas.Text == "SAYI GİRİN")
            {
                txt_Myas.Text = "";
            }
        }




        void Musteriekle()
        { //urun ekleme fonk tanititim
            Musteri Musteri =new Musteri();

           
            Musteri.TC = Tc;
            Musteri.Adisoyadi = Adisoyadi;
            Musteri.Telefonno = Telefonno;
            Musteri.Cinsiyet = cmb_cinsiyet.SelectedItem.ToString(); ;
            Musteri.Yas = Yas;

            Magaza.Musteriekle(Musteri);//Mağazada Musteri ekle fonksıyonu çağırdım 

        }

        private void button1_Click(object sender, EventArgs e)
        {

            //girilenleri kontrol ediyorum sayidan farkli ya da harftan farkli bir sey giririse
            
            Sayi = txt_Mtc.Text + txt_Mtelno.Text+ txt_Myas.Text;
            sayidegilise = Magaza.Sayi(Sayi);
            harfdegilise = Magaza.Harf(txt_Madisoyadi.Text);

            //BURDA HARF ALANLARI KÖNTRUL EDİYORUM EĞER KULLANCI ONDAN BİRİ DOLDURUMAYI UNUTTUR ISE HATA VERECEK
            if (txt_Madisoyadi.Text.Contains("HARF GİRİN"))
            {
                MessageBox.Show("HARF ALANI DOĞURU DOLDURUN", "ekleme yapamazsın  ", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }

            else
            {


                if (sayidegilise == false || harfdegilise == false)//burda kontrol ediyorum eger kullanci sayi /harf alana sayilardan /haftan farkli girdiririse 
                {
                    MessageBox.Show("Bilirtildiği gibi girin sayı ise sayı ve Harf ise harf ", "ekleme Yapamazsın  ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    // dışardan tum köntrol edilecek bilgileri boslukları silecegim ki hata azalatmasi icin 

                    Tc = int.Parse(txt_Mtc.Text.Replace(" ", string.Empty));
                    Adisoyadi = txt_Madisoyadi.Text.Replace(" ", string.Empty);
                    Telefonno = int.Parse(txt_Mtelno.Text.Replace(" ", string.Empty));
                    Yas = int.Parse(txt_Myas.Text.Replace(" ", string.Empty));



                    using (var connection = new SQLiteConnection(Magaza.project))//verı tabanı ile bağlantı kurmak
                    {//Dışardan alınacak bilgiler refransını koydum

                        connection.Open();//veri tabani actim
                                          // using (var cmm = new SQLiteCommand("SELECT count(*)FROM musteri WHERE tc='" + int.Parse(txt_Mtc.Text) + "'", connection))
                        using (var cmm = new SQLiteCommand($"SELECT count(*)FROM musteri WHERE tc='{ Tc}'", connection))
                        {//burda aynı kod olan sayıyıtıyorum 
                            SQLiteDataAdapter adapter = new SQLiteDataAdapter(cmm);
                            object obj = cmm.ExecuteScalar();//burda bir object tanıtım ve command verdiği sayı Barindiriyor
                            if (Convert.ToInt32(obj) > 0)//eğer bu Müşteri aslında varsa ekleme yapmaz
                            {
                                MessageBox.Show(txt_Mtc.Text.Replace(" ", string.Empty) + "TC esi olan Müşteri veri tabanda kayıtı bulundu", "ekleme yapamazsın  ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else//yoksa yapar
                            {
                                MessageBox.Show(txt_Mtc.Text.Replace(" ", string.Empty) + "Müşteri OLAN TC Başarıyla Eklenmiştir", "Ekleme Yapıldı ", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                Musteriekle();
                                this.Close();
                            }
                        }//using sql command sonu
                    }//using sqlconnectiction sonu 

                }

            }


          
        }
            }//1.kosull sonu
            

        }
