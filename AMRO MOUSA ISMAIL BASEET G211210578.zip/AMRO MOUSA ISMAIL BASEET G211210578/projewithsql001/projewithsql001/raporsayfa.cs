﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2021-2022 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:(3)PROJE
**				ÖĞRENCİ ADI............:AMRO MOUSA ISMAIL BASEET
**				ÖĞRENCİ NUMARASI.......:G211210578
**                         DERSİN ALINDIĞI GRUP...:2. Öğretim A grubu
****************************************************************************/

using System;
using System.Data;
using System.Windows.Forms;
using System.Drawing;
using System.Data.SQLite;

namespace projewithsql001
{
    public partial class raporsayfa : Form
    {
        SQLiteDataAdapter adapter;
        public raporsayfa()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterParent;//bir önceki sayfanının ortasında açılacak
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önler
            this.MaximizeBox = false;//form buytme engellir
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum
          
            dataGridView1.AutoResizeRows();//sütuna sığdırmak için
            dataGridView1.AutoResizeColumns();

        }
        void gidervgelirsteleme()
        {

            using (var connection = new SQLiteConnection(Magaza.project))//verı tabanı ile bağlantı kurmak
            {
                //bağlanacak veri tabanı adressi kompaylara vermek

                connection.Open();//veri tabanımı açtım
                //bağlanacak veri tabanı adressi kompaylara vermek


                adapter = new SQLiteDataAdapter("SELECT * FROM gidergelir WHERE  no IS NOT NULL", connection);//veri tabandaki tüm verileri getirdim 

                DataTable table = new DataTable();//bir tablo oluşturdum

                adapter.Fill(table);//oluşturduğum tablete veri tabandaki getirdiğim belgileri doldurdum
                dataGridView1.DataSource = table;//bu tablo datagridview e gönderdim

                dataGridView1.AutoResizeRows();//sütuna sığdırmak için
                dataGridView1.AutoResizeColumns();

            }
        }
        void satissteleme()
        {

            using (var connection = new SQLiteConnection(Magaza.project))//verı tabanı ile bağlantı kurmak
            {
                //bağlanacak veri tabanı adressi kompaylara vermek

                connection.Open();//veri tabanımı açtım

                adapter = new SQLiteDataAdapter("SELECT * FROM satis WHERE  satisno IS NOT NULL", connection);//veri tabandaki tüm verileri getirdim 

                DataTable table = new DataTable();//bir tablo oluşturdum

                adapter.Fill(table);//oluşturduğum tablete veri tabandaki getirdiğim belgileri doldurdum
                dataGridView1.DataSource = table;//bu tablo datagridview e gönderdim
                dataGridView1.AutoResizeRows();//sütuna sığdırmak için
                dataGridView1.AutoResizeColumns();


            }
        }
        void siparisteleme()
        {

            using (var connection = new SQLiteConnection(Magaza.project))//verı tabanı ile bağlantı kurmak
            {
                //bağlanacak veri tabanı adressi kompaylara vermek

                connection.Open();//veri tabanımı açtım

                adapter = new SQLiteDataAdapter("SELECT * FROM siparislist WHERE siparisno IS NOT NULL", connection);//veri tabandaki tüm verileri getirdim 

                DataTable table = new DataTable();//bir tablo oluşturdum

                adapter.Fill(table);//oluşturduğum tablete veri tabandaki getirdiğim belgileri doldurdum
                dataGridView1.DataSource = table;//bu tablo datagridview e gönderdim
                dataGridView1.AutoResizeRows();//sütuna sığdırmak için
                dataGridView1.AutoResizeColumns();


            }
        }
        void gidersteleme()
        {

            using (var connection = new SQLiteConnection(Magaza.project))//verı tabanı ile bağlantı kurmak
            {
                //bağlanacak veri tabanı adressi kompaylara vermek

                connection.Open();//veri tabanımı açtım

                adapter = new SQLiteDataAdapter("SELECT * FROM gidergelir WHERE tur='GIDER'", connection);//veri tabandaki tüm verileri getirdim 

                DataTable table = new DataTable();//bir tablo oluşturdum

                adapter.Fill(table);//oluşturduğum tablete veri tabandaki getirdiğim belgileri doldurdum
                dataGridView1.DataSource = table;//bu tablo datagridview e gönderdim
                dataGridView1.AutoResizeRows();//sütuna sığdırmak için
                dataGridView1.AutoResizeColumns();


            }
        }
        void gelirsteleme()
        {

            using (var connection = new SQLiteConnection(Magaza.project))//verı tabanı ile bağlantı kurmak
            {
                //bağlanacak veri tabanı adressi kompaylara vermek

                connection.Open();//veri tabanımı açtım

                adapter = new SQLiteDataAdapter("SELECT * FROM gidergelir WHERE tur='GELIR'", connection);//veri tabandaki tüm verileri getirdim 

                DataTable table = new DataTable();//bir tablo oluşturdum

                adapter.Fill(table);//oluşturduğum tablete veri tabandaki getirdiğim belgileri doldurdum
                dataGridView1.DataSource = table;//bu tablo datagridview e gönderdim

                dataGridView1.AutoResizeRows();//sütuna sığdırmak için
                dataGridView1.AutoResizeColumns();

            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            satissteleme();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            gidervgelirsteleme();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            siparisteleme();
        }

        private void button4_Click(object sender, EventArgs e)
        {
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            gidersteleme();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            gelirsteleme();
        }
    }
}
