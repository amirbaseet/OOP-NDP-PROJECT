﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2021-2022 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:(3)PROJE
**				ÖĞRENCİ ADI............:AMRO MOUSA ISMAIL BASEET
**				ÖĞRENCİ NUMARASI.......:G211210578
**                         DERSİN ALINDIĞI GRUP...:2. Öğretim A
****************************************************************************/

using System;
using System.Windows.Forms;
using System.Drawing;

namespace projewithsql001
{
    public partial class Yonetici_işlemi : Form
    {
        public Yonetici_işlemi()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterParent;//bir önceki sayfanının ortasında açılacak
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önler
            this.MaximizeBox = false;//form buytme engeller
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum

        }

        private void Yonetici_işlemi_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Mkontrulu mkontrulu = new Mkontrulu();
            mkontrulu.ShowDialog();
            this.Close();//formu kapatıyorum 

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            raporsayfa raporsayfa =new raporsayfa();
            raporsayfa.ShowDialog();
        }

        private void label4_Click(object sender, EventArgs e)
        {
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Giderekle giderekle = new Giderekle();
            giderekle.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Tedrkciekle tedrkciformu = new Tedrkciekle();
            tedrkciformu.ShowDialog();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            urunlarlist urunlarlist = new urunlarlist();
            urunlarlist.ShowDialog();
        }
    }
}
