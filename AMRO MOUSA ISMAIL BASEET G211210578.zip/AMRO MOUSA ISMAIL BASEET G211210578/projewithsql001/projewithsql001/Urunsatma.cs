﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2021-2022 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:(3)PROJE
**				ÖĞRENCİ ADI............:AMRO MOUSA ISMAIL BASEET
**				ÖĞRENCİ NUMARASI.......:G211210578
**                         DERSİN ALINDIĞI GRUP...:2. Öğretim A grubu
****************************************************************************/

using System;
using System.Windows.Forms;
using System.Drawing;
using System.Data.SQLite;

namespace projewithsql001
{
    public partial class Urunsatma : Form
    {
    
        
         string urunadi;
         string musteriadi;
         //tum sayi alanlari sayi stringde barindiracagim ki onu kontrol edecegim eger kullanci oraya sayilardan farkli girdirise
         string sayi;
        //ve onlari kullanarak islemi yapacagim

        bool sayidegilise;
        //çok kontrol edilecek için hepsıne statiğe yaptım
        public static int Kode;
        public static int Tc;

        public Urunsatma()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterParent;//bir önceki sayfanının ortasında açılacak
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önler
            this.MaximizeBox = false;//form buytme engellir
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum


            //tc alan icin PLACE HOLDER TANITIYORUM
            txt_mtc.Text = "SAYI GİRİN";
            txt_mtc.Click += Txt_mtc_Click;
            txt_mtc.GotFocus += Txt_mtc_GotFocus;
            txt_mtc.LostFocus += Txt_mtc_LostFocus;


            //urun kodu alan icin PLACE HOLDER TANITIYORUM
            txt_ukodu.Text = "SAYI GİRİN";
            txt_ukodu.Click += Txt_ukodu_Click;
            txt_ukodu.GotFocus += Txt_ukodu_GotFocus;
            txt_ukodu.LostFocus += Txt_ukodu_LostFocus;
        }
        //tc alan icin PLACE HOLDER TANITIYORUM

        private void Txt_mtc_LostFocus(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_mtc.Text))
            {
                txt_mtc.Text = "SAYI GİRİN";

            }
        }

        private void Txt_mtc_GotFocus(object sender, EventArgs e)
        {
            if (txt_mtc.Text == "SAYI GİRİN")
                txt_mtc.Text = "";
        }

        private void Txt_mtc_Click(object sender, EventArgs e)
        {
            if (txt_mtc.Text == "SAYI GİRİN")
                txt_mtc.Text = "";
        }
        //urun kodu alan icin PLACE HOLDER TANITIYORUM

        private void Txt_ukodu_LostFocus(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_ukodu.Text))
            {
                txt_ukodu.Text = "SAYI GİRİN";
            }

        }

        private void Txt_ukodu_GotFocus(object sender, EventArgs e)
        {
            if (txt_ukodu.Text == "SAYI GİRİN")
                txt_ukodu.Text = "";
        }


        private void Txt_ukodu_Click(object sender, EventArgs e)
        {
            if (txt_ukodu.Text == "SAYI GİRİN")
                txt_ukodu.Text = "";
        }





        void urunsat()
        {//urun satış fonk tanıtıyorum
            Urun urun = new Urun();//urun ve müşteri sınıfından yeni nesne üretim 
            Musteri Musteri = new Musteri();
            using (var connection = new SQLiteConnection(Magaza.project))//verı tabanı ile bağlantı kurmak
            {
                //bağlanacak veri tabanı adressi kompaylara vermek

                connection.Open();//veri tabanımı açtım

                //Dışardan alınacak bilgiler refransını koydum
                using (SQLiteCommand command = new SQLiteCommand($"SELECT adisoyadi FROM musteri WHERE tc =' {Tc } '"))
                {//getirilecek muşteri bilgileri müşterinin bilgiler iyle götürülecek
                    command.Connection = connection;
                    SQLiteDataReader reader = command.ExecuteReader();//okumak icin sqldatareader bir nesne üretim
                    while (reader.Read())//okurken  bilgileri atıyorum
                    {
                        Musteri.Adisoyadi = reader.GetString(0);//yap

                    }
                    connection.Close();//bağlantıya kapat

                }
                connection.Open();//veri tabanımı açtım

                using (SQLiteCommand command = new SQLiteCommand($"SELECT adi,fiat FROM Stock WHERE kode =' { Kode } '"))//getirilecek Urun bilgileri urun kodu yardımıla bilgiler  götürülecek
                {
                    command.Connection = connection;
                    SQLiteDataReader reader = command.ExecuteReader();//okumak icin
                    while (reader.Read())//okurken  bilgileri atıyorum
                    {
                        urun.Adi = (string)reader["adi"];
                        urun.Fiat = Convert.ToSingle(reader["fiat"]);

                    }


                }
                connection.Close();//bağlantı kapat
            }
           

           
            //burda dışardan bilgileri  muşteri ve urun sınıf özelliklerine atıyorum
            Musteri.TC = Tc;
            urun.Kode = Kode;

            urunadi = urun.Adi;
            musteriadi = Musteri.Adisoyadi;
            lbl_musteriadisoyadi.Text = musteriadi;
            lbl_urunadi.Text = urunadi;
            Magaza.Urunsat(Musteri, urun);
            //satış işlem olunca messege gösteriyior
            MessageBox.Show(urun.Adi + "  Urun Başariyla satilmistir", "satma işlemi yaplıldı", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }



        private void button1_Click(object sender, EventArgs e)
        {
            // dışardan tum köntrol edilecek bilgileri bosluklar silecegimki hata azalatmasi icin 

            sayi = txt_mtc.Text + txt_ukodu.Text;
            //girilenleri kontrol ediyorum sayidan farkli ya da harftan farkli bir sey giririse
            sayidegilise = Magaza.Sayi(sayi);
            //Tum bilgeleri doldurmak zorunludur
           
                if (sayidegilise == false)//Bu alanlari sadece sayılar girmeli
                {
                    MessageBox.Show("Bu alanda sadece sayılar girmeli", " satın alamazsınız", MessageBoxButtons.OK, MessageBoxIcon.Error);//burda kontrol ediyorum eger kullanci sayi dan farkli bir sey girdiririse 


                }
                else
                {
                // dışardan tum köntrol edilecek bilgileri bosluklar silecegimki hata azalatmasi icin 
                    Tc = int.Parse(txt_mtc.Text.Replace(" ", string.Empty));
                    Kode = int.Parse(txt_ukodu.Text.Replace(" ", string.Empty));


                    using (var connection = new SQLiteConnection(Magaza.project))//verı tabanı ile bağlantı kurmak
                    {
                        //bağlanacak veri tabanı adressi kompaylara vermek

                        connection.Open();//veri tabanımı açtım

                        SQLiteCommand command = new SQLiteCommand("SELECT count(*)FROM musteri WHERE tc='" + Tc + "'", connection);//veritabanda eger  musteri var olup olmadigini kontrol ediyor
                        SQLiteCommand comm = new SQLiteCommand("SELECT count(*)FROM Stock WHERE kode='" + Kode + "'", connection);//veritabanda eger  musteri var olup olmadigini kontrol ediyor

                        SQLiteDataAdapter adapter = new SQLiteDataAdapter(command);

                        SQLiteDataAdapter adapter2 = new SQLiteDataAdapter(comm);

                        object obj = command.ExecuteScalar();//burda bir object tanıtım ve command verdiği sayı Barindiriyor
                        object obj2 = comm.ExecuteScalar();//burda bir object tanıtım ve command verdiği sayı Barindiriyor

                        if ((Convert.ToInt32(obj) <= 0) && (Convert.ToInt32(obj2) <= 0))
                        {
                            MessageBox.Show("  Girdiğiniz Müşteri Ve Urun Veri Tabanda Bulunmadı", "satma işlemi yapılmadı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else if (Convert.ToInt32(obj) <= 0)//eğer girildiğ müşteri tc ve urun kodu veri tabanda blununmazsa bir messege gösteriyor
                        {
                            MessageBox.Show("Girdiğiniz  Müşteri Veri Tabanda Bulunmadı", "satma işlemi yapılmadı", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        }
                        else if (Convert.ToInt32(obj2) <= 0)
                        {
                            MessageBox.Show(" Girdiğiniz Urun Veri Tabanda Bulunmadı", "satma işlemi yapılmadı", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        }

                        else
                        {//varsa 

                            urunsat();
                            this.Close();//formu kapatıyorum 
                        }


                    }
                }
           
        }


    }
}
    

                

            
    

