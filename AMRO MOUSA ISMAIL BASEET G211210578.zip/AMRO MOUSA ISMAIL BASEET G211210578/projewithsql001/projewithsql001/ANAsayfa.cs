﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2021-2022 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:(3)PROJE
**				ÖĞRENCİ ADI............:AMRO MOUSA ISMAIL BASEET
**				ÖĞRENCİ NUMARASI.......:G211210578
**                         DERSİN ALINDIĞI GRUP...:2. Öğretim A
****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace projewithsql001
{
    public partial class ANAsayfa : Form
    {
        public ANAsayfa()
        {
            this.StartPosition = FormStartPosition.CenterScreen;//form ekran ortasinda baslasin
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önler
            this.MaximizeBox = false;//form buytme engellir
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
           Yonetici_işlemi yonetici_Işlemi=new Yonetici_işlemi();
            yonetici_Işlemi.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Musteriform Musteriform =new Musteriform();
            Musteriform.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            sipariset sipariset=new sipariset();
            sipariset.ShowDialog();
        }
    }
}
