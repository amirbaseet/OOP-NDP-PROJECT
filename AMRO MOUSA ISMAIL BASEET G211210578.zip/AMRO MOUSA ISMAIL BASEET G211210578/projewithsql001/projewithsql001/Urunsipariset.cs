﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2021-2022 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:(3)PROJE
**				ÖĞRENCİ ADI............:AMRO MOUSA ISMAIL BASEET
**				ÖĞRENCİ NUMARASI.......:G211210578
**                         DERSİN ALINDIĞI GRUP...:2. Öğretim A grubu
****************************************************************************/

using System;
using System.Windows.Forms;
using System.Drawing;
using System.Data.SQLite;

namespace projewithsql001
{
    public partial class Urunsipariset : Form
    {
        //çok kontrol edilecek için hepsıne statiğe yaptım
        public static float Fiat;
        public static string Depo;
        public static string Adi;
        public static int Raf;
        public static int kod;
        public static string Renk;
        public static int Tc;

        //tum sayi alanlari sayi stringde barindiracagim ki onu kontrol edecegim eger kullanci oraya sayilardan farkli girdirise
        string sayi;
        //tum harf alanlari hrf stringde barindiracagim ki onu kontrol edecegim eger kullanci oraya harftan farkli girdirise
        string hrf;
        //ve onlari kullanarak islemi yapacagim
        bool sayidegilise;
        bool harfdegilise;
        bool fiatdegilse;

        public Urunsipariset()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterParent;//bir önceki sayfanının ortasında açılacak
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önler
            this.MaximizeBox = false;//form buytme engellir
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum
            cmb_ketagori.SelectedIndex = 0;
            cmb_cinsiyet.SelectedIndex = 0;

            //placeholder tanitiyorum///////////////////////////////////////////////////////////////////////////////////


            //Urun renk alan icin PLACE HOLDER TANITIYORUM


            txt_Ufiati.Text = "SAYI GİRİN";
            txt_Ufiati.GotFocus += Txt_Ufiati_GotFocus;
            txt_Ufiati.LostFocus += Txt_Ufiati_LostFocus;
            txt_Ufiati.Click += Txt_Ufiati_Click;


            txt_Udepo.Text = "HARF GİRİN";
            txt_Udepo.GotFocus += Txt_Udepo_GotFocus;
            txt_Udepo.LostFocus += Txt_Udepo_LostFocus;
            txt_Udepo.Click += Txt_Udepo_Click;

            //Urun adi kodu alan icin PLACE HOLDER TANITIYORUM

            txt_Uadi.Text = "HARF GİRİN";
            txt_Uadi.GotFocus += Txt_Uadi_GotFocus;
            txt_Uadi.LostFocus += Txt_Uadi_LostFocus;
            txt_Uadi.Click += Txt_Uadi_Click;

            txt_Uraf.Text = "SAYI GİRİN";
            txt_Uraf.Click += Txt_Uraf_Click;
            txt_Uraf.GotFocus += Txt_Uraf_GotFocus;
            txt_Uraf.LostFocus += Txt_Uraf_LostFocus;



            //Urun raf kodu alan icin PLACE HOLDER TANITIYORUM

            txt_Ukodu.Text = "SAYI GİRİN";
            txt_Ukodu.Click += Txt_Ukodu_Click;
            txt_Ukodu.GotFocus += Txt_Ukodu_GotFocus;
            txt_Ukodu.LostFocus += Txt_Ukodu_LostFocus;

            //Urunfiati  alan icin PLACE HOLDER TANITIYORUM
            txt_Urenk.Text = "HARF GİRİN";
            txt_Urenk.GotFocus += Txt_Urenk_GotFocus;
            txt_Urenk.LostFocus += Txt_Urenk_LostFocus;
            txt_Urenk.Click += Txt_Urenk_Click;

            //tc alan icin PLACE HOLDER TANITIYORUM
            txt_Ttc.Text = "SAYI GİRİN";
            txt_Ttc.GotFocus += Txt_Ttc_GotFocus;
            txt_Ttc.Click += Txt_Ttc_Click;
            txt_Ttc.LostFocus += Txt_Ttc_LostFocus;

        }

        //Urun renk alan icin PLACE HOLDER TANITIYORUM
        private void Txt_Urenk_Click(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_Urenk.Text == "HARF GİRİN")
            {
                txt_Urenk.Text = "";
            }
        }

        private void Txt_Urenk_LostFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (string.IsNullOrWhiteSpace(txt_Urenk.Text))
            {
                txt_Urenk.Text = "HARF GİRİN";
            }
        }

        private void Txt_Urenk_GotFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_Urenk.Text == "HARF GİRİN")
            {
                txt_Urenk.Text = "";
            }
        }




        //Urun depo alan icin PLACE HOLDER TANITIYORUM
        private void Txt_Udepo_Click(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_Udepo.Text == "HARF GİRİN")
            {
                txt_Udepo.Text = "";
            }
        }

        private void Txt_Udepo_LostFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (string.IsNullOrWhiteSpace(txt_Udepo.Text))
            {
                txt_Udepo.Text = "HARF GİRİN";
            }
        }
        private void Txt_Udepo_GotFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_Udepo.Text == "HARF GİRİN")
            {
                txt_Udepo.Text = "";
            }
        }



        //Urun adi  alan icin PLACE HOLDER TANITIYORUM
        private void Txt_Uadi_Click(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_Uadi.Text == "HARF GİRİN")
            {
                txt_Uadi.Text = "";
            }
        }
        private void Txt_Uadi_LostFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (string.IsNullOrWhiteSpace(txt_Uadi.Text))

            {
                txt_Uadi.Text = "HARF GİRİN";
            }
        }
        private void Txt_Uadi_GotFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_Uadi.Text == "HARF GİRİN")
            {
                txt_Uadi.Text = "";
            }
        }




        //Urun raf  alan icin PLACE HOLDER TANITIYORUM
        private void Txt_Uraf_LostFocus(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_Uraf.Text))
            {
                txt_Uraf.Text = "SAYI GİRİN";
            }

        }
        private void Txt_Uraf_GotFocus(object sender, EventArgs e)
        {
            if (txt_Uraf.Text == "SAYI GİRİN")
                txt_Uraf.Text = "";
        }
        private void Txt_Uraf_Click(object sender, EventArgs e)
        {
            if (txt_Uraf.Text == "SAYI GİRİN")
                txt_Uraf.Text = "";
        }



        //urun kodu alan icin PLACE HOLDER TANITIYORUM
        private void Txt_Ukodu_LostFocus(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_Ukodu.Text))
            {
                txt_Ukodu.Text = "SAYI GİRİN";
            }

        }
        private void Txt_Ukodu_GotFocus(object sender, EventArgs e)
        {
            if (txt_Ukodu.Text == "SAYI GİRİN")
                txt_Ukodu.Text = "";
        }
        private void Txt_Ukodu_Click(object sender, EventArgs e)
        {
            if (txt_Ukodu.Text == "SAYI GİRİN")
                txt_Ukodu.Text = "";
        }



        //Urunfiati  alan icin PLACE HOLDER TANITIYORUM
        private void Txt_Ufiati_Click(object sender, EventArgs e)
        {
            if (txt_Ufiati.Text == "SAYI GİRİN")
                txt_Ufiati.Text = "";
        }
        private void Txt_Ufiati_LostFocus(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_Ufiati.Text))
            {
                txt_Ufiati.Text = "SAYI GİRİN";

            }
        }
        private void Txt_Ufiati_GotFocus(object sender, EventArgs e)
        {
            if (txt_Ufiati.Text == "SAYI GİRİN")
                txt_Ufiati.Text = "";
        }



        //tc alan icin PLACE HOLDER TANITIYORUM

        private void Txt_Ttc_LostFocus(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_Ttc.Text))
            {
                txt_Ttc.Text = "SAYI GİRİN";

            }
        }

        private void Txt_Ttc_Click(object sender, EventArgs e)
        {

            if (txt_Ttc.Text == "SAYI GİRİN")
                txt_Ttc.Text = "";
        }

        private void Txt_Ttc_GotFocus(object sender, EventArgs e)
        {
            if (txt_Ttc.Text == "SAYI GİRİN")
                txt_Ttc.Text = "";
        }

        void Sipariset()//sipareş etme metodu tanıtıyorum 
        {
            // dışardan tum alınacak bilgileri bosluklar silecegimki hata azalatmasi icin 

            //tedarikci ,sipareşlistesi sınıflardan birer nesne uretim
            Tedarikci Tedarikci = new Tedarikci();
            Tdrkcisiparis Siparislistesi = new Tdrkcisiparis();
            
            //stok,sipariş dosyalara eklenecek bilgiler
            Tedarikci.Tc = Tc;
            Siparislistesi.Urunkodu = kod;
            Siparislistesi.Urunadi = Adi;
            Siparislistesi.Cinsiyet = cmb_cinsiyet.SelectedItem.ToString();
            Siparislistesi.Urunrenk = Renk;
            Siparislistesi.Ketagori = cmb_ketagori.SelectedItem.ToString();

            //Sadece stok dosyaya ekleneceek bilgiler
            Siparislistesi.Fiat = Fiat;
            Siparislistesi.Depo = Depo;
            Siparislistesi.Raf = Raf;
            using (var connection = new SQLiteConnection(Magaza.project))//verı tabanı ile bağlantı kurmak
            {
                //bağlanacak veri tabanı adressi kompaylara vermek

                //burada tedarikci tc esi kullanarak tedarikci dosyaya gidip tedarikcı adı götürüp stok dosyaya eklenecek 
                using (SQLiteCommand command = new SQLiteCommand("SELECT tedarikciadi FROM tdrkci WHERE tedarikcitc  ='" +Tc + "'"))//getirilecek Urun bilgileri urun kodu yardımıla bilgiler  götürülecek
                {
                    connection.Open();//veri tabani actim

                    command.Connection = connection;
                    SQLiteDataReader reader = command.ExecuteReader();//okumak icin
                    while (reader.Read())//okurken  bilgileri atıyorum
                    {
                        Tedarikci.Adi = (string)reader["tedarikciadi"];
                    }


                }
                connection.Close();//bağlantı kapat
            }

            Magaza.Sipariset_stokekle(Tedarikci, Siparislistesi);//Mağaza sınıfından siperiş etme metodu çağırdım
        }


        private void button1_Click(object sender, EventArgs e)
        {

            //girilenleri kontrol ediyorum sayidan farkli ya da harftan farkli bir sey giririse

            sayi = txt_Ttc.Text + txt_Ukodu.Text+ txt_Uraf.Text;
            hrf = txt_Udepo.Text+ txt_Urenk.Text+ txt_Uadi.Text;
            //tum harf alanlari hrf stringde barindiracagim ki onu kontrol edecegim eger kullanci oraya harftan farkli girdirise
            fiatdegilse = Magaza.Fiat(txt_Ufiati.Text);
            sayidegilise = Magaza.Sayi(sayi);
            harfdegilise = Magaza.Harf(hrf);


            //BURDA HARF ALANLARI KÖNTRUL EDİYORUM EĞER KULLANCI ONDAN BİRİ DOLDURUMAYI UNUTTUR ISE HATA VERECEK
            if (hrf.Contains("HARF GİRİN"))
            {
                MessageBox.Show("HARF ALANI DOĞURU DOLDURUN", "ekleme yapamazsın  ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {

                if (fiatdegilse == false || sayidegilise == false || harfdegilise == false)
                //Bilirtildiği gibi girin sayı ise sayı ve Harf ise harf
                {
                    MessageBox.Show("Bilirtildiği gibi girin sayı ise sayı ,Harf ise harf  ", "ekleme Yapamazsın  ", MessageBoxButtons.OK, MessageBoxIcon.Error);//burda kontrol ediyorum eger kullanci sayi /harf alana sayilardan /haftan farkli girdiririse 

                }
                else
                {
                    // dışardan tum köntrol edilecek bilgileri bosluklar silecegimki hata azalatmasi icin 
                    Tc = int.Parse(txt_Ttc.Text.Replace(" ", string.Empty));
                    Adi = txt_Uadi.Text.Replace(" ", string.Empty);
                    Renk = txt_Urenk.Text.Replace(" ", string.Empty); ;
                    kod = int.Parse(txt_Ukodu.Text.Replace(" ", string.Empty));
                    Fiat = Convert.ToSingle(txt_Ufiati.Text.Replace(" ", string.Empty));
                    Depo = txt_Udepo.Text.Replace(" ", string.Empty);
                    Raf = int.Parse(txt_Uraf.Text.Replace(" ", string.Empty));


                    using (var connection = new SQLiteConnection(Magaza.project))//verı tabanı ile bağlantı kurmak
                    {//Dışardan alınacak bilgiler refransını koydum
                        object obj;
                        object obj2;
                        connection.Open();//veri tabani actim
                        using (SQLiteCommand command = new SQLiteCommand("SELECT count(*)FROM tdrkci WHERE tedarikcitc='" + Tc + "'", connection))
                        {
                            SQLiteDataAdapter adapter = new SQLiteDataAdapter(command);
                            obj = command.ExecuteScalar();//burda bir object tanıtım ve command verdiği sayı Barindiriyor




                        };//veritabanda eger  tedarikci var olup olmadigini kontrol ediyor
                        using (SQLiteCommand command2 = new SQLiteCommand("SELECT count(*)FROM Stock WHERE kode = '" + kod + "'", connection))
                        { //veritabanda eger  urun var olup olmadigini kontrol ediyor
                            obj2 = command2.ExecuteScalar();//burda bir object tanıtım ve command verdiği sayı Barindiriyor
                        }
                        if ((Convert.ToInt32(obj) <= 0) && !(Convert.ToInt32(obj2) <= 0))
                        {
                            MessageBox.Show("Tedarikçi veri tabanda bulunmadi ve Urun veri Tabanda bulundu ", "ekleme yapamazsın  ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }


                        else if ((Convert.ToInt32(obj) <= 0))//eğer girildiğ tedarikcinin tc veri tabanda blununmazsa ve urun kodu veri tabanda varsa bir messege gösteriyor
                        {
                            MessageBox.Show("Tedarikçi var Olduğundan emin ol ", "ekleme yapamazsın  ", MessageBoxButtons.OK, MessageBoxIcon.Error);


                        }
                        else if (!(Convert.ToInt32(obj2) <= 0))//Eğer girildiği urun stock ta var ıse ekleme yapamaz
                        {
                            MessageBox.Show("Urun veri tabanda bulundu ", "ekleme yapamazsın  ", MessageBoxButtons.OK, MessageBoxIcon.Error);


                        }

                        else
                        {//tedarikçi varsa ve urun yoksa
                            Sipariset();
                            MessageBox.Show(Adi + " Urun Başarıyla Sipariş Etmiştir", "Ekleme Yapıldı ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            MessageBox.Show(Adi + " Urun Başarıyla Stok Dosyasına Eklnmiştir", "Ekleme Yapıldı ", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            this.Close();//formu kapatıyorum 
                        }

                        connection.Close();//Bağlantı kapatıyorum
                    }
                }
            }
          
        }

    }
}