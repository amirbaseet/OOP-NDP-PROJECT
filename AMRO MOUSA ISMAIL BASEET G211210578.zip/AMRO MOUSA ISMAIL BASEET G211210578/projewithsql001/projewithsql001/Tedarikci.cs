﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2021-2022 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:(3)PROJE
**				ÖĞRENCİ ADI............:AMRO MOUSA ISMAIL BASEET
**				ÖĞRENCİ NUMARASI.......:G211210578
**                         DERSİN ALINDIĞI GRUP...:2. Öğretim A grubu
****************************************************************************/

namespace projewithsql001
{
    internal class Tedarikci
    {
        int tc;
        string adi;
        int telno;

        public int Tc { get => tc; set => tc = value; }
        public string Adi { get => adi; set => adi = value; }
        public int Telno { get => telno; set => telno = value; }

        internal Magaza Magaza
        {
            get => default;
            set
            {
            }
        }
    }
}
