﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2021-2022 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:(3)PROJE
**				ÖĞRENCİ ADI............:AMRO MOUSA ISMAIL BASEET
**				ÖĞRENCİ NUMARASI.......:G211210578
**                         DERSİN ALINDIĞI GRUP...:2. Öğretim A
****************************************************************************/

namespace projewithsql001
{
    internal class Musteri
    {
        int tc;
        string adisoyadi;
        int telefonno;
        string cinsiyet;
        int yas;
        public int TC { get => tc; set => tc = value; }
        public string Adisoyadi { get => adisoyadi; set => adisoyadi = value; }
        public int Telefonno { get => telefonno; set => telefonno = value; }
        public string Cinsiyet { get => cinsiyet; set => cinsiyet = value; }    
        public int Yas { get => yas; set => yas = value; }   
       
    }
   
}
