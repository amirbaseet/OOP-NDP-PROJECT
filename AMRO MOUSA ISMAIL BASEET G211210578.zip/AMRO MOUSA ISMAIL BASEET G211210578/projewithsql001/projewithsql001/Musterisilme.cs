﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2021-2022 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:(3)PROJE
**				ÖĞRENCİ ADI............:AMRO MOUSA ISMAIL BASEET
**				ÖĞRENCİ NUMARASI.......:G211210578
**                         DERSİN ALINDIĞI GRUP...:2. Öğretim A grubu
****************************************************************************/

using System;
using System.Data;
using System.Windows.Forms;
using System.Drawing;
using System.Data.SQLite;

namespace projewithsql001
{
    public partial class Musterisilme : Form
    {
        public Musterisilme()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterParent;//bir önceki sayfanının ortasında açılacak
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önler
            this.MaximizeBox = false;//form buytme engellir
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum
            dataGridView1.AutoResizeColumns();
            dataGridView1.AutoResizeRows();//sütuna sığdırmak için
            this.dataGridView1.AutoSize = true;

        }
        void Urun_listeleme()
        {
            bool sayidegilise;
            sayidegilise = Magaza.Sayi(txt_MSilme.Text);
            if (txt_MSilme.Text.Length != 0&&(!string.IsNullOrWhiteSpace(txt_MSilme.Text)))
            {
                if (sayidegilise==false)
                {

                
                    MessageBox.Show("Bu alanda sadece sayılar girmeli", "Silme Yapamazsın  ", MessageBoxButtons.OK, MessageBoxIcon.Error);//burda kontrol ediyorum eger kullanci sayi  sayilardan  farkli girdiririse 

                }
                else
                {
                    using (var connection = new SQLiteConnection(Magaza.project))//verı tabanı ile bağlantı kurmak
                    {
                        //bağlanacak veri tabanı adressi kompaylara vermek

                        connection.Open();//veri tabanımı açtım

                        SQLiteDataAdapter adapter = new SQLiteDataAdapter($"SELECT * FROM musteri WHERE tc= {int.Parse(txt_MSilme.Text)} ", connection);//veri tabandaki tüm verileri getirdim 

                        DataTable table = new DataTable();//bir tablo oluşturdum

                        adapter.Fill(table);//oluşturduğum tablete veri tabandaki getirdiğim belgileri doldurdum
                        dataGridView1.DataSource = table;//bu tablo datagridview e gönderdim
                      
                        dataGridView1.AutoResizeColumns();
                        dataGridView1.AutoResizeRows();//sütuna sığdırmak için
                        this.dataGridView1.AutoSize = true;

                    }
                }
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool sayidegilise;
            sayidegilise = Magaza.Sayi(txt_MSilme.Text);
            if (!(string.IsNullOrWhiteSpace(txt_MSilme.Text)))
            {
                if (sayidegilise==false)//Bu alanda sadece sayılar girmeli
                
                {
                    MessageBox.Show("Bu alanda sadece sayılar girmeli  ve alan boşluk içermemeli", "Silme Yapamazsın  ", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
                else
                {


                    using (var connection = new SQLiteConnection(Magaza.project))//verı tabanı ile bağlantı kurmak
                    {
                        //bağlanacak veri tabanı adressi kompaylara vermek

                        connection.Open();//veri tabanımı açtım//Dışardan alınacak bilgiler refransını koydum

                        using (var command = new SQLiteCommand("SELECT count(*)FROM musteri WHERE tc='" + Int32.Parse(txt_MSilme.Text) + "'", connection))
                        {//burda aynı kod olan sayıyıtıyorum 
                            SQLiteDataAdapter adapter = new SQLiteDataAdapter(command);
                            object obj = command.ExecuteScalar();//burda bir object tanıtım ve command verdiği sayı Barindiriyor
                            if (Convert.ToInt32(obj) > 0)//eğer bu Müşteri aslında varsa silme yapmaz
                            {
                                Magaza.Musterisilme(int.Parse(txt_MSilme.Text));
                                MessageBox.Show(txt_MSilme.Text + "TC esi olan Müşteri veri tabandan Başarıyla Silmiştir", "Silme Yapıldı ", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                this.Close();

                            }
                            else//yoksa yapar
                            {
                                MessageBox.Show(txt_MSilme.Text + "TC esi olan Müşteri veri tabanda kayıtı bulundu", "Silme Yapamazsın  ", MessageBoxButtons.OK, MessageBoxIcon.Error);

                            }
                        }//using sql command sonu
                    }//using sqlconnectiction sonu 
                }
            }
            else
            {
                MessageBox.Show("Tum alnaları Doldurmanız gerek", "Silme yapamazsın  ", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }

        }
           

        private void txt_MSilme_TextChanged(object sender, EventArgs e)
        {
            Urun_listeleme();
        }
    }
    }

