﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2021-2022 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:(3)PROJE
**				ÖĞRENCİ ADI............:AMRO MOUSA ISMAIL BASEET
**				ÖĞRENCİ NUMARASI.......:G211210578
**                         DERSİN ALINDIĞI GRUP...:2. Öğretim A
****************************************************************************/

using System;
using System.Windows.Forms;
using System.Data.SQLite;
namespace projewithsql001
{
    internal class Magaza
    {
        
        public static bool Fiat(string girilen)//eğer girilenden bir fiattan başka girilirse false verecek
        {
            girilen.ToCharArray();
            bool test = true;

            for (int i = 0; i < girilen.Length; i++)
            {
                if (!(char.IsNumber(girilen[i]) || (girilen[i] == '.'||girilen[i]==' ')))
                {
                    test = false;
                }


            }
            return test;

        }
        public static bool Harf(string girilen)//eğer girilenden bir harfden başka girilirse false verecek
        {
            girilen.ToCharArray();
            bool test = true;

            for (int i = 0; i < girilen.Length; i++)
            {
                if (!(char.IsLetter(girilen[i]) || girilen[i] == ' '))
                {
                    test = false;
                }


            }
            return test;

        }
        public static bool Sayi(string girilen)//eğer girilenden bir harfden başka girilirse false verecek
        {
            girilen.ToCharArray();
            bool test = true;

            for (int i = 0; i < girilen.Length; i++)
            {
                if (!(char.IsNumber(girilen[i]) || girilen[i] == ' '))
                {
                    test = false;
                }


            }
            return test;

        }
        //***************************URURN FONKSIYONLARI BASLANGIC*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************
        //ÇOk kullanılacak için public static yaptım

        //public static string project = $"Data Source ={Application.StartupPath}\\project.db;Version=3;";
         public static string project = $"Data Source =.\\project.db;Version=3;";
        //***************************GIDER EKLE FONKSIYONLARI BASLANGIC**********************************************************************************************************************************************************************************************************************************************************************************
        public static void Giderekle(Giderler Gider)
        {

            using (var sqlConnection = new SQLiteConnection(project))//verı tabanı ile bağlantı kurmak
            {
                //burda veri tabana emir veriyorum 
                ///veri tabana eklenecek değeri veriyorum
                using (var cmm = new SQLiteCommand($"INSERT INTO  gidergelir(tur,borc,adi,zaman)Values('{Gider.Tur.ToUpper()}','{Gider.Borc}','" +
                                                                                                      $"{Gider.Adi.ToUpper()}','{DateTime.Now}') "
                                                                                                        , sqlConnection))
                {

                    cmm.Connection.Open();
                    cmm.ExecuteNonQuery();//sütünün sayısına  ve bilgileri donduruluyor
                }//using sql command sonu


            }//using sqlconnectiction sonu 

        }

        //***************************GIDER EKLE FONKSIYONLARI BITIS**********************************************************************************************************************************************************************************************************************************************************************************
        public static void Urunsilme(int kode)
        {
                //Dışardan alınacak bilgiler refransını koydum ve AYNI kodu unun olan sutun silinecek

                using (var sqlConnection = new SQLiteConnection(project))//verı tabanı ile bağlantı kurmak
                {

                sqlConnection.Open();

                ///veri tabandan silenecek değeri kodunu veriyorum
                using (var command = new SQLiteCommand("DELETE FROM Stock WHERE kode=@kode", sqlConnection))
                {
                    command.Parameters.AddWithValue("kode", kode);
                    command.ExecuteNonQuery();//sütünün sayısına  ve bilgileri donduruluyor
                }//using sql command sonu

                sqlConnection.Close();//veri tabani kapatim
            }//using sqlconnectiction sonu 
        }
        //***************************URURN FONKSIYONLARI BITIS**********************************************************************************************************************************************************************************************************************************************************************************

        //***************************MUSTERI FONKSIYONLARI BASLANGIC**********************************************************************************************************************************************************************************************************************************************************************************
        public static void Musteriekle(Musteri Musteri)
        {

            ///veri tabana eklenecek değeri veriyorum
            using (var Connection = new SQLiteConnection(project))//verı tabanı ile bağlantı kurmak
            {
                using (SQLiteCommand cmm = new SQLiteCommand($"INSERT INTO musteri(tc,adisoyadi,telefonno,cinsiyet,yas)Values" +
                                                             $"('{Musteri.TC}','{Musteri.Adisoyadi.ToUpper()}','{Musteri.Telefonno}','" +
                                                             $"{Musteri.Cinsiyet.ToUpper()}','{Musteri.Yas}')", Connection))
                {

                    cmm.Connection.Open();//bağlantı açtım
                    cmm.ExecuteNonQuery();


                }
            }
        }
        public static void Musterisilme(int tc)
        {
            using (var Connection = new SQLiteConnection(project))//verı tabanı ile bağlantı kurmak
            {//Dışardan alınacak bilgiler refransını koydum

                Connection.Open();//veri tabani actim
                //Dışardan alınacak bilgiler refransını koydum ve AYNI tc inin olan sutun silinecek
                using (var command = new SQLiteCommand("DELETE FROM musteri WHERE tc=@tc", Connection))
                {
                    command.Parameters.AddWithValue("tc", tc);
                    command.ExecuteNonQuery();


                }//using sql command sonu
                Connection.Close();//veri tabani kapatim

            }//using sqlconnectiction sonu 
        }
        //***************************MUSTERI FONKSIYONLARI BITIS**********************************************************************************************************************************************************************************************************************************************************************************

        //***************************SATIS FONKSIYONLARI BASLANGIC**********************************************************************************************************************************************************************************************************************************************************************************
        public static void Urunsat(Musteri Musteri, Urun urun)
        {
            Giderler gider =new Giderler();// Giderler sınıfından bir nesne tanıtım hadefim bu => bir urun satıldığı zaman gelirvgider veri tabana gelir olorak kayıt etsin
            using (var Connection = new SQLiteConnection(project))//verı tabanı ile bağlantı kurmak
            {
                //bağlanacak veri tabanı adressi kompaylara vermek

                Connection.Open();//veri tabanımı açtım
                                  //Dışardan alınacak bilgiler refransını koydum
                using (SQLiteCommand command = new SQLiteCommand($"INSERT INTO satis(musteritc,musteriad,urunadi,urunkodu,urunfiat,satistarihi)Values"
                                                               + $"('{Musteri.TC}','{Musteri.Adisoyadi.ToUpper()}','" +
                                                               $"{urun.Adi.ToUpper()}','{urun.Kode}','{urun.Fiat}'," +
                                                               $"'{DateTime.Now}') ", Connection))
                {
                    command.ExecuteNonQuery();
                    Urunsilme(urun.Kode);//satış olunca satıldığı urun yok olacak 
                   
                    //gidervgelir veritabana kayd edilececek bilgeleri tanitim
                    gider.Borc = urun.Fiat;
                    gider.Tur = "GELIR";
                    gider.Adi = urun.Adi;
                    Giderekle(gider);//satış olunca gider veri tabana eklenecek
                }
                Connection.Close();//bağlantı kapatım
            }
            
        }
        //***************************SATIS FONKSIYONLARI BITIS**********************************************************************************************************************************************************************************************************************************************************************************

        //***************************TEDARIKCI FONKSIYONLARI BASLANGIC**********************************************************************************************************************************************************************************************************************************************************************************

        public static void Tedarikciekle(Tedarikci Tedarikci)
        {
            using (var connection = new SQLiteConnection(project))//verı tabanı ile bağlantı kurmak
            {
                //bağlanacak veri tabanı adressi kompaylara vermek

                connection.Open();//veri tabanımı açtım

                //Dışardan alınacak bilgiler refransını koydum
                using (SQLiteCommand command = new SQLiteCommand($"INSERT INTO tdrkci(tedarikcitc,tedarikciadi,tedarikcitelefonno)Values(" +
                                                                 $"'{Tedarikci.Tc}','{Tedarikci.Adi.ToUpper()}'," +
                                                                 $"'{Tedarikci.Telno}') ", connection))
                {
                    // " command.Parameters.AddWithValue("kodu bilgiler veritabana eklemek için kullanılır

                    //command.Connection.Open();
                    command.ExecuteNonQuery();
                }//using sql command sonu
                connection.Close();//bağlantı kapatım

            }//using sqlconnectiction sonu 

        }
        //***************************TEDARIKCI FONKSIYONLARI BITIS**********************************************************************************************************************************************************************************************************************************************************************************

        //***************************SIPARIS FONKSIYONLARI BASLANGIC**********************************************************************************************************************************************************************************************************************************************************************************

        public static void Sipariset_stokekle(Tedarikci Tedarikci,Tdrkcisiparis Siparislistesi) 
        {

            using (var connection = new SQLiteConnection(project))//verı tabanı ile bağlantı kurmak
            {
                //bağlanacak veri tabanı adressi kompaylara vermek

                connection.Open();//veri tabanımı açtım

                //Dışardan alınacak bilgiler refransını koydum
                using (SQLiteCommand command = new SQLiteCommand($"INSERT INTO siparislist(tedarikcitc,tedarikciadi,urunkodu,urunadi,uruncinsiyet,urunrenk,urunketgori,fiat,siparistarihi)Values" +
                                                                 $"('{Tedarikci.Tc}','{ Tedarikci.Adi.ToUpper()}','" +
                                                                 $"{Siparislistesi.Urunkodu}','{Siparislistesi.Urunadi.ToUpper()}'," +
                                                                 $"'{Siparislistesi.Cinsiyet.ToUpper()}','{Siparislistesi.Urunrenk.ToUpper()}','" +
                                                                 $"{Siparislistesi.Ketagori.ToUpper()}','" +
                                                                 $"{Siparislistesi.Fiat}'," +
                                                                 $"'{DateTime.Now}') ", connection))
                {

                    command.ExecuteNonQuery();
                }//using sql command sonu

                using (SQLiteCommand command1 = new SQLiteCommand($"INSERT INTO Stock(kode,depo,raf,adi,cinsiyet,renk,ketagori,fiat)Values" +
                                                                 $"('{Siparislistesi.Urunkodu}','{Siparislistesi.Depo.ToUpper()}','" +
                                                                 $"{Siparislistesi.Raf}','{Siparislistesi.Urunadi.ToUpper()}'" +
                                                                 $",'{Siparislistesi.Cinsiyet.ToUpper()}','{Siparislistesi.Urunrenk.ToUpper()}','" +
                                                                 $"{ Siparislistesi.Ketagori.ToUpper()}'" +
                                                                 $",'{ Siparislistesi.Fiat}') "
                                                                 , connection))
                {
                    command1.ExecuteNonQuery();
                }//using sql command sonu
                connection.Close();//bağlantı kapatım
            }//using sqlconnectiction sonu 
        }
        //***************************SIPARIS FONKSIYONLARI BITIS**********************************************************************************************************************************************************************************************************************************************************************************
    }
}
