﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2021-2022 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:(3)PROJE
**				ÖĞRENCİ ADI............:AMRO MOUSA ISMAIL BASEET
**				ÖĞRENCİ NUMARASI.......:G211210578
**                         DERSİN ALINDIĞI GRUP...:2. Öğretim A grubu
****************************************************************************/

using System;
using System.Data;
using System.Windows.Forms;
using System.Drawing;
using System.Data.SQLite;

namespace projewithsql001
{
    public partial class Tedrkciekle : Form
    {
        SQLiteDataAdapter adapter;
        //tum sayi alanlari sayi stringde barindiracagim ki onu kontrol edecegim eger kullanci oraya sayilardan farkli girdirise
        string sayi;
        //tum harf alanlari hrf stringde barindiracagim ki onu kontrol edecegim eger kullanci oraya harftan farkli girdirise
        string hrf;

        //ve onlari kullanarak islemi yapacagim
        bool sayidegilise;
        bool harfdegilise;
        //çok kontrol edilecek için hepsıne statiğe yaptım

        public static string Adi;
        public static int Tc;
        public static int Telno;

        public Tedrkciekle()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterParent;//bir önceki sayfanının ortasında açılacak
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önler
            this.MaximizeBox = false;//form buytme engellir
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum
            dataGridView1.AutoResizeRows();//sütuna sığdırmak için
            dataGridView1.AutoResizeColumns();
            this.dataGridView1.AutoSize = true;

            //adisoyadi alan icin PLACE HOLDER TANITIYORUM
            txt_Tadi.Text = "HARF GİRİN";
            txt_Tadi.GotFocus += Txt_Tadi_GotFocus;
            txt_Tadi.LostFocus += Txt_Tadi_LostFocus;
            txt_Tadi.Click += Txt_Tadi_Click;

            //tc alan icin PLACE HOLDER TANITIYORUM

            txt_Ttc.Text = "SAYI GİRİN";
            txt_Ttc.GotFocus += Txt_Ttc_GotFocus;
            txt_Ttc.LostFocus += Txt_Ttc_LostFocus;
            txt_Ttc.Click += Txt_Ttc_Click;

            //telno  alan icin PLACE HOLDER TANITIYORUM

            txt_Ttelno.Text = "SAYI GİRİN";
            txt_Ttelno.GotFocus += Txt_Ttelno_GotFocus;
            txt_Ttelno.LostFocus += Txt_Ttelno_LostFocus;
            txt_Ttelno.Click += Txt_Ttelno_Click;
        }

        //tc alan icin PLACE HOLDER TANITIYORUM

        private void Txt_Ttc_Click(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_Ttc.Text == "SAYI GİRİN")
            {
                txt_Ttc.Text = "";
            }
        }
        private void Txt_Ttc_GotFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_Ttc.Text == "SAYI GİRİN")
            {
                txt_Ttc.Text = "";
            }
        }
        private void Txt_Ttc_LostFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (string.IsNullOrWhiteSpace(txt_Ttc.Text))
            {
                txt_Ttc.Text = "SAYI GİRİN";
            }
        }

        //adisoyadi alan icin PLACE HOLDER TANITIYORUM

        private void Txt_Tadi_Click(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_Tadi.Text == "HARF GİRİN")
            {
                txt_Tadi.Text = "";
            }
        }

        private void Txt_Tadi_LostFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (string.IsNullOrWhiteSpace(txt_Tadi.Text))
            {
                txt_Tadi.Text = "HARF GİRİN";
            }
        }

        private void Txt_Tadi_GotFocus(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_Tadi.Text == "HARF GİRİN")
            {
                txt_Tadi.Text = "";
            }
        }



        //telno  alan icin PLACE HOLDER TANITIYORUM

        private void Txt_Ttelno_GotFocus(object sender, EventArgs e)
        {

            //placeholder tanitiyorum
            if (txt_Ttelno.Text == "SAYI GİRİN")
            {
                txt_Ttelno.Text = "";
            }
        }
        private void Txt_Ttelno_LostFocus(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_Ttelno.Text))
            {
                txt_Ttelno.Text = "SAYI GİRİN";
            }
        }
        private void Txt_Ttelno_Click(object sender, EventArgs e)
        {
            //placeholder tanitiyorum
            if (txt_Ttelno.Text == "SAYI GİRİN")
            {
                txt_Ttelno.Text = "";
            }
        }


        void tedarikcilisteleme()
        {

            using (var connection = new SQLiteConnection(Magaza.project))//verı tabanı ile bağlantı kurmak
            {
                //bağlanacak veri tabanı adressi kompaylara vermek

                connection.Open();//veri tabanımı açtım

                adapter = new SQLiteDataAdapter("SELECT * FROM tdrkci WHERE  tedarikcitc IS NOT NULL", connection);//veri tabandaki tüm verileri getirdim 

                DataTable table = new DataTable();//bir tablo oluşturdum

                adapter.Fill(table);//oluşturduğum tablete veri tabandaki getirdiğim belgileri doldurdum
                dataGridView1.DataSource = table;//bu tablo datagridview e gönderdim

                dataGridView1.AutoResizeColumns();
                dataGridView1.AutoResizeRows();//sütuna sığdırmak için
                this.dataGridView1.AutoSize = true;
            }
        }
        public void tedarikciekle() //ekleme fonk tanititim
        {
            // dışardan tum alınacak bilgileri bosluklar silecegimki hata azalatmasi icin 


            Tedarikci tedarikci = new Tedarikci();
            tedarikci.Tc=Tc;
            tedarikci.Adi = txt_Tadi.Text.Replace(" ", string.Empty);
            tedarikci.Telno = Telno;

            Magaza.Tedarikciekle(tedarikci);
        }


        private void button1_Click(object sender, EventArgs e)
        {
            // dışardan tum köntrol edilecek bilgileri bosluklar silecegimki hata azalatmasi icin 



            //tum sayi alanlari sayi stringde barindiracagim ki onu kontrol edecegim eger kullanci oraya sayilardan farkli girdirise
            sayi = txt_Ttc.Text + txt_Ttelno.Text;
            //tum harf alanlari hrf stringde barindiracagim ki onu kontrol edecegim eger kullanci oraya harftan farkli girdirise
            hrf = txt_Tadi.Text;
            sayidegilise = Magaza.Sayi(sayi);
            harfdegilise = Magaza.Harf(hrf);
            //BURDA HARF ALANLARI KÖNTRUL EDİYORUM EĞER KULLANCI ONDAN BİRİ DOLDURUMAYI UNUTTUR ISE HATA VERECEK
            if (hrf.Contains("HARF GİRİN"))
            {
                MessageBox.Show("HARF ALANI DOĞURU DOLDURUN", "ekleme yapamazsın  ", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {


                if (sayidegilise == false || harfdegilise == false)//burda kontrol ediyorum eger kullanci sayi /harf alana sayilardan /haftan farkli girdiririse 
                {
                    MessageBox.Show("Bilirtildiği gibi girin sayı ise sayı ve Harf ise harf ", "ekleme Yapamazsın  ", MessageBoxButtons.OK, MessageBoxIcon.Error);


                }
                else
                {
                    Tc = int.Parse(txt_Ttc.Text.Replace(" ", string.Empty));
                    Adi = txt_Tadi.Text.Replace(" ", string.Empty);
                    Telno = int.Parse(txt_Ttelno.Text.Replace(" ", string.Empty));

                    using (var connection = new SQLiteConnection(Magaza.project))//verı tabanı ile bağlantı kurmak
                    {//Dışardan alınacak bilgiler refransını koydum
                        object obj;
                        connection.Open();//veri tabani actim
                                          //burada kontrol edilecek sayi ondan bosluklari silecegimki hata azalmasi icin
                        using (SQLiteCommand command = new SQLiteCommand("SELECT count(*)FROM tdrkci WHERE tedarikcitc='" + Tc + "'", connection))
                        {
                            adapter = new SQLiteDataAdapter(command);
                            obj = command.ExecuteScalar();//burda bir object tanıtım ve command verdiği sayı Barindiriyor
                            if ((Convert.ToInt32(obj) <= 0))//eğer girildiğ tedarikcinin tc veri tabanda blununmazsa ve urun kodu veri tabanda varsa bir messege gösteriyor
                            {
                                MessageBox.Show(Tc + "TC esi olan Tedarikçi veri tabana Başarıyla eklenmiştir", "Ekleme Yapıldı ", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                tedarikciekle();
                                tedarikcilisteleme();


                            }
                            else
                            {
                                MessageBox.Show(Tc + "TC esi olan Tedarikçi veri tabanda kayıtı bulundu", "ekleme yapamazsın  ", MessageBoxButtons.OK, MessageBoxIcon.Error);

                            }
                        }
                    }
                }
            }




        }

        private void Tedrkciformu_Load(object sender, EventArgs e)
        {
            tedarikcilisteleme();
        }

        private void Tedrkciformu_Activated(object sender, EventArgs e)
        {
            tedarikcilisteleme();

        }
    }
}
