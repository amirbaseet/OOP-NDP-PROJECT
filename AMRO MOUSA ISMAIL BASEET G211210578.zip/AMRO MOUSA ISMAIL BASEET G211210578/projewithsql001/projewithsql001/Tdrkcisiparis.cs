﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2021-2022 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:(3)PROJE
**				ÖĞRENCİ ADI............:AMRO MOUSA ISMAIL BASEET
**				ÖĞRENCİ NUMARASI.......:G211210578
**                         DERSİN ALINDIĞI GRUP...:2. Öğretim A
****************************************************************************/


namespace projewithsql001
{
    internal class Tdrkcisiparis
    {
        int urunkodu;
        string urunadi;
        string urunrenk;
        string cinsiyet;
        string ketagori;
        float fiat;
        string depo;
        int raf;
        public int Urunkodu { get => urunkodu; set => urunkodu = value; }
        public string Urunadi { get => urunadi; set => urunadi = value; }
        public string Cinsiyet { get => cinsiyet; set => cinsiyet = value; }
        public float Fiat{ get => fiat; set => fiat = value; }
        public string Urunrenk { get => urunrenk; set => urunrenk = value; }
        public string Ketagori { get => ketagori; set => ketagori = value; }
        public string Depo { get => depo; set => depo=value; }
        public int Raf { get => raf; set => raf = value; }

        internal Magaza Magaza
        {
            get => default;
            set
            {
            }
        }
    }
}
